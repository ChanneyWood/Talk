package com.example.a12579.design.my.update;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.a12579.design.R;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by 12579 on 2018/5/31.
 */

public class UpdateMsg extends AppCompatActivity implements View.OnClickListener{

    private EditText et_gender,et_age,et_address,et_sign;
    private TextView tv_name;
    private Button btn_submit,btn_cancel;
    private String name;
    private Boolean result=false;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_user_msg);
        ImageView imageView = findViewById(R.id.my_update_iv_my);
        imageView.setColorFilter(Color.BLACK);
        et_gender = findViewById(R.id.update_et_gender);
        et_address = findViewById(R.id.update_et_address);
        et_age = findViewById(R.id.update_et_age);
        et_sign = findViewById(R.id.update_et_sign);
        tv_name = findViewById(R.id.update_tv_name);
        initEditText();
        btn_cancel = findViewById(R.id.update_cancel_btn);
        btn_submit = findViewById(R.id.update_save_btn);
        btn_submit.setOnClickListener(this);
        btn_cancel.setOnClickListener(this);
    }

    private void initEditText() {
        SharedPreferences preferences = getSharedPreferences("userdata", Context.MODE_PRIVATE);
        name = preferences.getString("name","");
        String address = preferences.getString("address","");
        String gender = preferences.getString("gender","");
        String age = preferences.getString("age","");
        String sign = preferences.getString("sign","");
        if (!address.equals("null")){
            et_address.setText(address);
        }
        if (!gender.equals("null")){
            et_gender.setText(gender);
        }
            tv_name.setText(name);

        if (!sign.equals("null")){
            et_sign.setText(sign);
        }
        if (!age.equals("null")){
            et_age.setText(age);
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.update_save_btn:
                String address = et_address.getText().toString();
                String gender = et_gender.getText().toString();
                String age = et_age.getText().toString();
                String sign = et_sign.getText().toString();

                try {
                    updateMsg(address,gender,age,sign);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                try {
                    getUserMsg(name);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                toastResult();
                finish();
                break;
            case R.id.update_cancel_btn:
                finish();
                break;
        }
    }

    public void getUserMsg(final String name) throws InterruptedException {
        new Thread(new Runnable() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void run() {
                try{
                    OkHttpClient client = new OkHttpClient();
                    RequestBody requestBody = new FormBody.Builder()
                            .add("name",name)
                            .build();
                    Request request = new Request.Builder()
                            .url("http://47.94.157.71/design/design/getusermsg")
                            .post(requestBody)
                            .build();
                    Response response = client.newCall(request).execute();
                    String responseData = response.body().string();
                    parseJSONWithJSONObject_save_user_msg(responseData);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }).start();
        Thread.sleep(500);
    }

    public void parseJSONWithJSONObject_save_user_msg(String responseData) {
        //            JSONObject jsonObject = new JSONObject(responseData);
//            Map<String,Object> map = new HashMap<>();
//            map.putAll((Map<? extends String, ?>) jsonObject);
        Map<String,Object> map = new HashMap<>();
        Gson gson = new Gson();
        map = gson.fromJson(responseData,map.getClass());
        SharedPreferences.Editor editor = getSharedPreferences("userdata", Context.MODE_PRIVATE).edit();
        editor.putString("name", (String) map.get("username"));
        editor.putString("address", (String) map.get("address"));
        editor.putString("gender", (String) map.get("gender"));
        editor.putString("email", (String) map.get("email"));
        editor.putString("age", (String) map.get("age"));
        editor.putString("sign", (String) map.get("sign"));
        editor.putBoolean("isLogin",true);
        System.out.println("parseJsoning");
        editor.apply();
    }

    private void updateMsg(String address, String gender, String age, String sign) throws InterruptedException {
        if (address.equals(""))
            address = "null";
        if (gender.equals(""))
            gender = "null";
        if (age.equals(""))
            age = "null";
        if (sign.equals(""))
            sign = "null";
        final String finalAddress = address;
        final String finalGender = gender;
        final String finalSign = sign;
        final String finalAge = age;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try{
                    OkHttpClient client = new OkHttpClient();
                    System.out.println(finalAddress);
                    System.out.println(finalAge);
                    System.out.println(finalGender);
                    System.out.println(finalSign);
                    RequestBody requestBody = new FormBody.Builder()
                            .add("name",name)
                            .add("address", finalAddress)
                            .add("gender", finalGender)
                            .add("sign", finalSign)
                            .add("age", finalAge)
                            .build();
                    Request request = new Request.Builder()
                            .url("http://47.94.157.71/design/design/updateusermsg")
                            .post(requestBody)
                            .build();
                    Response response = client.newCall(request).execute();
                    String responseData = response.body().string();
                    parseJSONWithJSONObject(responseData);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }).start();
            Thread.sleep(500);
    }
    private void parseJSONWithJSONObject(String responseData) {
        try {
            JSONObject jsonObject = new JSONObject(responseData);
            result = jsonObject.getBoolean("result");
            System.out.println("getresult");
//            if (result==false){
//                Toast.makeText(this,"发送失败",Toast.LENGTH_SHORT).show();
//            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    public void toastResult(){
        if (result==false){
            Toast.makeText(this,"发送失败",Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this,"发送成功",Toast.LENGTH_SHORT).show();
        }
    }
}
