package com.example.a12579.design.my.follow;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.bigkoo.svprogresshud.SVProgressHUD;
import com.example.a12579.design.R;
import com.example.a12579.design.delete.DeleteAdapter;
import com.example.a12579.design.delete.LoadMoreListView;
import com.example.a12579.design.delete.SelectDelete;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class FollowActivity extends AppCompatActivity {

    private SVProgressHUD svProgressHUD;
    private ListView listView;
    private ArrayList<Map<String,Object>> list = new ArrayList<Map<String, Object>>();//从网络中获得的所有数据
    private FollowAdapter followAdapter;
    private String name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_follow);
        svProgressHUD = new SVProgressHUD(this);

        SharedPreferences preferences = getSharedPreferences("userdata", Context.MODE_PRIVATE);
        name = preferences.getString("name","");
        listView = findViewById(R.id.follow_list);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //点击列表后
                if (list.size()>0&&list!=null)
                {
                    HashMap<String,Object> map = (HashMap<String, Object>) list.get(i);
                    Intent intent = new Intent(FollowActivity.this, FollowShareActivity.class);
                    intent.putExtra("data", map);//只能传序列化的数据
                    startActivity(intent);
                }

            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        svProgressHUD.show();
        getData();
        svProgressHUD.dismiss();
    }

    private void getData() {
        list.clear();
        if (followAdapter!=null)
            followAdapter.notifyDataSetChanged();
        new Thread(new Runnable() {
            @Override
            public void run() {
                OkHttpClient okHttpClient=new OkHttpClient();
                //服务器返回的地址
                RequestBody requestBody = new FormBody.Builder()
                        .add("name",name)
                        .build();
                Request request=new Request.Builder()
                        .url("http://47.94.157.71/design/design/getmyfollow")
                        .post(requestBody).build();
                try {
                    Response response=okHttpClient.newCall(request).execute();
                    //获取到数据
                    String data=response.body().string();
                    //把数据传入解析josn数据方法
                    jsonJX(data);

                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }).start();


    }

    private void jsonJX(String data) {
        JSONObject jsonObject;
        if (data!=null){
            try {
                JSONArray jsonArray = new JSONArray(data);
                for (int i = 0;i<jsonArray.length();i++){
                    jsonObject = jsonArray.getJSONObject(i);
                    Map<String,Object> map = new HashMap();
                    String username = jsonObject.getString("username");
                    String gender = jsonObject.getString("gender");
                    String sign = jsonObject.getString("sign");

                    map.put("name",username);
                    map.put("gender",gender);
                    map.put("sign",sign);
                    list.add(map);
                }
                //System.out.println(list.toString());
                Message message = new Message();
                message.what = 1;

                handler.sendMessage(message);


            }catch (Exception e){
                e.printStackTrace();
            }
        }





    }


    public Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case 1:
                    Collections.reverse(list);
                    followAdapter = new FollowAdapter(FollowActivity.this,list);
                    listView.setAdapter(followAdapter);
                    followAdapter.notifyDataSetChanged();
                    break;
            }
        }
    };
}
