package com.example.a12579.design.delete;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.example.a12579.design.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class SelectDelete extends AppCompatActivity implements View.OnClickListener {

    private TextView s_title,s_name,s_text,s_agree,s_disagree,s_time,s_comment_num;
    ImageView iv_agree,iv_disagree,iv_comment,iv_follow;
    Boolean is_agree_select=false;
    Boolean is_disagree_select=false;
    //private ListView listView;
    private String comment_id;
    private String comment_user_name;
    private String followname;
    boolean isfollowed = false;
    boolean islogin = false;


    private  Boolean result=false;
    HashMap<String,Object> map;
    private ArrayList<Map<String,Object>> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        map = (HashMap<String, Object>) intent.getSerializableExtra("data");

        setContentView(R.layout.select_delete_layout);
        s_title = findViewById(R.id.select_title);
        s_name = findViewById(R.id.select_name);
        s_text = findViewById(R.id.select_text);
        s_time = findViewById(R.id.select_time);
        s_agree = findViewById(R.id.select_agree);
        s_disagree = findViewById(R.id.select_disagree);
        s_comment_num = findViewById(R.id.select_comment);

        comment_user_name = map.get("name").toString();
        s_title.setText(map.get("title").toString());
        s_name.setText(comment_user_name);
        s_text.setText(map.get("text").toString());
        s_time.setText(map.get("time").toString());
        s_disagree.setText(map.get("disagree").toString());
        s_agree.setText(map.get("agree").toString());
        s_comment_num.setText(map.get("comment_num").toString());

        comment_id = map.get("comment").toString();



        iv_agree = findViewById(R.id.select_img_agree);
        iv_disagree = findViewById(R.id.select_img_disagree);
        iv_comment = findViewById(R.id.select_img_comment);
        iv_comment.setColorFilter(android.R.color.black);
        iv_follow = findViewById(R.id.select_user_follow);
        initFollow();
        iv_agree.setOnClickListener(this);
        iv_disagree.setOnClickListener(this);
        iv_comment.setOnClickListener(this);
        iv_follow.setOnClickListener(this);


    }

    private void initFollow() {
        SharedPreferences preferences = getSharedPreferences("userdata", Context.MODE_PRIVATE);
        followname = preferences.getString("name","");
        islogin = preferences.getBoolean("isLogin",false);
        if (islogin)
            isfollow(followname,comment_user_name);
        if (isfollowed){
            iv_follow.setImageResource(R.drawable.yiguanzhu);
            System.out.println(isfollowed);
        }
    }

    private void isfollow(final String fname, final String fedanme) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                OkHttpClient client = new OkHttpClient();
                RequestBody requestBody = new FormBody.Builder()
                        .add("fname",fname)
                        .add("fedname",fedanme)
                        .build();
                Request request = new Request.Builder()
                        .url("http://47.94.157.71/design/design/isfollow")
                        .post(requestBody)
                        .build();
                Response response = null;
                try {
                    response = client.newCall(request).execute();
                    String responseData = response.body().string();
                    JSONObject jsonObject = new JSONObject(responseData);
                    isfollowed = jsonObject.getBoolean("result");
                    System.out.println(isfollowed);
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }).start();
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.select_img_agree:
                if (is_agree_select==false&&is_disagree_select==false){
                    iv_agree.setImageResource(R.drawable.agree_selects);
                    addagree();
                    is_agree_select = true;
                    int agree = Integer.parseInt(map.get("agree").toString());
                    s_agree.setText(agree+1+"");
                }
                break;
            case R.id.select_img_disagree:
                if (is_disagree_select==false&&is_agree_select==false){
                    iv_disagree.setImageResource(R.drawable.disagree_select);
                    adddisagree();
                    is_disagree_select = true;
                    int disagree = Integer.parseInt(map.get("disagree").toString());
                    s_disagree.setText(disagree+1+"");
                }
                break;
            case R.id.select_img_comment:
                Intent i = new Intent(this,CommentList.class);
                i.putExtra("data",list);
                i.putExtra("comment_id",comment_id);
                startActivity(i);
                break;
            case R.id.select_user_follow:
                if (islogin==false){
                    Toast.makeText(this,"请先登录",Toast.LENGTH_SHORT).show();
                    return;
                }else if (isfollowed==true){
                    deleteFollow(followname,comment_user_name);
                    iv_follow.setImageResource(R.drawable.guanzhu);
                    isfollowed = false;
                    return;
                }else if (isfollowed==false){
                    addFollow(followname,comment_user_name);
                    iv_follow.setImageResource(R.drawable.yiguanzhu);
                    isfollowed = true;
                    return;
                }

                break;
        }
    }

    private void deleteFollow(final String fname, final String fedname) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                OkHttpClient client = new OkHttpClient();
                RequestBody requestBody = new FormBody.Builder()
                        .add("fname",fname)
                        .add("fedname",fedname)
                        .build();
                Request request = new Request.Builder()
                        .url("http://47.94.157.71/design/design/deletefollow")
                        .post(requestBody)
                        .build();
                Response response = null;
                try {
                    response = client.newCall(request).execute();
                    String responseData = response.body().string();
                    JSONObject jsonObject = new JSONObject(responseData);
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private void addFollow(final String fname, final String fedname) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                OkHttpClient client = new OkHttpClient();
                RequestBody requestBody = new FormBody.Builder()
                        .add("fname",fname)
                        .add("fedname",fedname)
                        .build();
                Request request = new Request.Builder()
                        .url("http://47.94.157.71/design/design/addfollow")
                        .post(requestBody)
                        .build();
                Response response = null;
                try {
                    response = client.newCall(request).execute();
                    String responseData = response.body().string();
                    JSONObject jsonObject = new JSONObject(responseData);
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }).start();

    }


    private void addagree() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try{
                    OkHttpClient client = new OkHttpClient();
                    RequestBody requestBody = new FormBody.Builder()
                            .add("id",comment_id)
                            .build();
                    Request request = new Request.Builder()
                            .url("http://47.94.157.71/design/design/addagree")
                            .post(requestBody)
                            .build();
                    Response response = client.newCall(request).execute();
                    String responseData = response.body().string();
                    parseJSONWithJSONObject(responseData);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private void adddisagree() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try{
                    OkHttpClient client = new OkHttpClient();
                    RequestBody requestBody = new FormBody.Builder()
                            .add("id",comment_id)
                            .build();
                    Request request = new Request.Builder()
                            .url("http://47.94.157.71/design/design/adddisagree")
                            .post(requestBody)
                            .build();
                    Response response = client.newCall(request).execute();
                    String responseData = response.body().string();
                    parseJSONWithJSONObject(responseData);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }).start();
    }
    private void parseJSONWithJSONObject(String responseData) {
        try {
            JSONObject jsonObject = new JSONObject(responseData);
            result = jsonObject.getBoolean("result");
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }











}
