package com.example.a12579.design.food;

import android.app.Fragment;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.RequiresApi;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;

import com.bigkoo.svprogresshud.SVProgressHUD;
import com.example.a12579.design.R;
import com.example.a12579.design.delete.DeleteAdapter;
import com.example.a12579.design.delete.LoadMoreListView;
import com.example.a12579.design.delete.SelectDelete;
import com.example.a12579.design.my.own.MyShareActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by 12579 on 2018/6/1.
 */

public class FoodFragment extends Fragment{


    private SVProgressHUD svProgressHUD;
    private LoadMoreListView listView;
    private ClearEditText editText;
    private ArrayList<Map<String,Object>> list = new ArrayList<Map<String, Object>>();//从网络中获得的所有数据
    private ArrayList<Map<String,Object>> data = new ArrayList<Map<String, Object>>();//加载入listview的数据
    private int index;//已加载数据
    private int maxNum = 50;//每次加载的最大数据
    private int length;//总数据长度
    private FoodAdapter adapter;
    public static FoodFragment newInstance(){
        FoodFragment foodFragment = new FoodFragment();
        return foodFragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        index = 0;
        length = 0;
        svProgressHUD = new SVProgressHUD(getActivity());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_food, container, false);
        listView = view.findViewById(R.id.food_list);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (list.size()>0&&list!=null)
                {
                    HashMap<String,Object> map = (HashMap<String, Object>) adapter.getItem(i);
                    Intent intent = new Intent(getActivity(), SelectFood.class);
                    intent.putExtra("data", map);//只能传序列化的数据
                    startActivity(intent);
                }
            }
        });
        editText = view.findViewById(R.id.food_et);
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                adapter.getFilter().filter(charSequence);
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        svProgressHUD.show();
        getData();
        svProgressHUD.dismiss();
    }

    private void getData() {
        list.clear();
        data.clear();
        if (adapter!=null)
            adapter.notifyDataSetChanged();
//        if(adapter!=null){
//            adapter.notifyDataSetChanged();
//        }
        //从网页获取评论信息
        new Thread(new Runnable() {
            @Override
            public void run() {
                OkHttpClient okHttpClient=new OkHttpClient();
                //服务器返回的地址
                Request request=new Request.Builder()
                        .url("http://47.94.157.71/design/design/getfood").build();
                try {
                    Response response=okHttpClient.newCall(request).execute();
                    //获取到数据
                    String data=response.body().string();
                    //把数据传入解析josn数据方法
                    jsonJX(data);

                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

            }
        }).start();


    }

    private void jsonJX(String data) {
        JSONObject jsonObject;
        if (data!=null){
            try {
                JSONArray jsonArray = new JSONArray(data);
                for (int i = 0;i<jsonArray.length();i++){
                    jsonObject = jsonArray.getJSONObject(i);
                    Map<String,Object> map = new HashMap();
                    String name = jsonObject.getString("food_name");
                    String img_url = jsonObject.getString("food_url");
                    String food_msg = jsonObject.getString("food_msg");

                    map.put("name",name);
                    map.put("url",img_url);
                    map.put("msg",food_msg);

                    list.add(map);
                }
                //System.out.println(list.toString());
                Message message = new Message();
                message.what = 1;

                handler.sendMessage(message);


            }catch (Exception e){
                e.printStackTrace();
            }
        }





    }


    public Handler handler = new Handler(){
        @RequiresApi(api = Build.VERSION_CODES.M)
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case 1:
                    index = 0;
                    length = list.size();
                    //System.out.println("list_size =  "+length);
                    Collections.reverse(list);
                    //复制一部分
                    for (int i = 0;i<maxNum&&i<length;i++,index++)
                    {
                        if (list!=null&&list.size()>0)
                            data.add(list.get(i));
                        // System.out.println("index1="+i);
                    }
                    adapter = new FoodAdapter(getContext(),data);
                    listView.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                    listView.setOnLoadMoreListener(new LoadMoreListView.OnLoadMoreListener() {
                        @Override
                        public void onloadMore() {
                            loadMore();
                        }
                    });
                    break;
            }
        }
    };

    private void loadMore() {
        new Thread(){
            @Override
            public void run() {
                super.run();
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                //data.clear();
                int i=0;
                for (;i<maxNum&&index+i<length;i++)
                {
                    if (list!=null&&list.size()>0)
                        data.add(list.get(i+index));
                    //System.out.println("index2="+i);
                }
                index += i;

                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        adapter.notifyDataSetChanged();
                        listView.setLoadCompleted();
                    }
                });
            }
        }.start();
    }
}
