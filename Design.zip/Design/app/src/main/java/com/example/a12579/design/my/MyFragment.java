package com.example.a12579.design.my;

import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.example.a12579.design.R;
import com.example.a12579.design.my.follow.FollowActivity;
import com.example.a12579.design.my.own.MyShareActivity;
import com.example.a12579.design.my.update.UpdateMsg;


/**
 * Created by 12579 on 2018/img3/21.
 */

public class MyFragment extends Fragment implements View.OnClickListener {
    private Button btn_out,btn_edit,btn_follow,btn_share;
    private TextView tv_gender,tv_age,tv_address,tv_sign,tvName;
    public static MyFragment newInstance(String param1) {
        MyFragment fragment = new MyFragment();
        Bundle args = new Bundle();
        args.putString("name", param1);
        fragment.setArguments(args);
        return fragment;
    }

    public MyFragment() {

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_my, container, false);

        tvName = view.findViewById(R.id.my_name);
        tv_address = view.findViewById(R.id.my_tv_address);
        tv_age = view.findViewById(R.id.my_tv_age);
        tv_gender = view.findViewById(R.id.my_tv_gender);
        tv_sign = view.findViewById(R.id.my_tv_sign);

        initTextView();
        btn_out = view.findViewById(R.id.my_btn_out);
        btn_edit = view.findViewById(R.id.my_btn_update_msg);
        btn_follow = view.findViewById(R.id.my_btn_follow);
        btn_share = view.findViewById(R.id.my_btn_submit);
        btn_out.setOnClickListener(this);
        btn_edit.setOnClickListener(this);
        btn_share.setOnClickListener(this);
        btn_follow.setOnClickListener(this);
        return view;
    }

    private void initTextView() {
        SharedPreferences preferences = getActivity().getSharedPreferences("userdata", Context.MODE_PRIVATE);
        String name = preferences.getString("name","");
        String address = preferences.getString("address","");
        String gender = preferences.getString("gender","");
        String age = preferences.getString("age","");
        String sign = preferences.getString("sign","");
        tvName.setText(name);
        if (!gender.equals("null")){
            tv_gender.setText(gender);
        }
        if (!address.equals("null")){
            tv_address.setText(address);
        }
        if (!age.equals("null")){
            tv_age.setText(age);
        }
        if (!sign.equals("null")){
            tv_sign.setText(sign);
        }
    }

    @Override
    public void onClick(View view) {
        Intent intent;
        switch (view.getId()){

            case R.id.my_btn_out:
                SharedPreferences.Editor editor = getActivity().getSharedPreferences("userdata", Context.MODE_PRIVATE).edit();
                editor.putBoolean("isLogin",false);
                editor.apply();
                FragmentTransaction fm = getActivity().getFragmentManager().beginTransaction();
                LoginFragment loginFragment = LoginFragment.newInstance("我");
                // 将 fragment_container View 中的内容替换为此 Fragment ，
                // 然后将该事务添加到返回堆栈，以便用户可以向后导航
                fm.replace(R.id.tbb, loginFragment);
                fm.addToBackStack(null);
                // 执行事务
                fm.commit();
                break;
            case R.id.my_btn_update_msg:
                intent = new Intent(getActivity(),UpdateMsg.class);
                startActivity(intent);
                break;
            case R.id.my_btn_submit:
                intent = new Intent(getActivity(), MyShareActivity.class);
                startActivity(intent);
                break;
            case R.id.my_btn_follow:
                intent = new Intent(getActivity(), FollowActivity.class);
                startActivity(intent);
                break;

        }
    }

    @Override
    public void onResume() {
        super.onResume();
        initTextView();
    }
}
