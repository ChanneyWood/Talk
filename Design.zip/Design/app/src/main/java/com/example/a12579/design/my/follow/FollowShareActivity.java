package com.example.a12579.design.my.follow;

import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;

import com.bigkoo.svprogresshud.SVProgressHUD;
import com.example.a12579.design.R;
import com.example.a12579.design.delete.DeleteAdapter;
import com.example.a12579.design.delete.LoadMoreListView;
import com.example.a12579.design.delete.SelectDelete;
import com.example.a12579.design.my.own.MyShareActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class FollowShareActivity extends AppCompatActivity {

    private SVProgressHUD svProgressHUD;
    private LoadMoreListView listView;
    private ArrayList<Map<String,Object>> list = new ArrayList<Map<String, Object>>();//从网络中获得的所有数据
    private ArrayList<Map<String,Object>> data = new ArrayList<Map<String, Object>>();//加载入listview的数据
    private int index;//已加载数据
    private int maxNum = 8;//每次加载的最大数据
    private int length;//总数据长度
    private DeleteAdapter adapter;
    private String name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        index = 0;
        length = 0;
        svProgressHUD = new SVProgressHUD(this);
        setContentView(R.layout.activity_follow_share);
        Intent intent = getIntent();
        HashMap<String,Object> map = (HashMap<String, Object>) intent.getSerializableExtra("data");
        name = (String) map.get("name");
        listView = findViewById(R.id.follow_share_list);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //点击列表后
                if (list.size()>0&&list!=null)
                {
                    HashMap<String,Object> map = (HashMap<String, Object>) list.get(i);
                    Intent intent = new Intent(FollowShareActivity.this, SelectDelete.class);
                    intent.putExtra("data", map);//只能传序列化的数据
                    startActivity(intent);
                }

            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        svProgressHUD.show();
        getData();
        svProgressHUD.dismiss();
    }

    private void getData() {
        list.clear();
        data.clear();
        if (adapter!=null)
            adapter.notifyDataSetChanged();
//        if(adapter!=null){
//            adapter.notifyDataSetChanged();
//        }
        //从网页获取评论信息
        new Thread(new Runnable() {
            @Override
            public void run() {
                OkHttpClient okHttpClient=new OkHttpClient();
                //服务器返回的地址
                RequestBody requestBody = new FormBody.Builder()
                        .add("name",name)
                        .build();
                Request request=new Request.Builder()
                        .url("http://47.94.157.71/design/design/getmyshare")
                        .post(requestBody).build();
                try {
                    Response response=okHttpClient.newCall(request).execute();
                    //获取到数据
                    String data=response.body().string();
                    //把数据传入解析josn数据方法
                    jsonJX(data);

                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

            }
        }).start();
    }

    private void jsonJX(String data) {
        JSONObject jsonObject;
        if (data!=null){
            try {
                JSONArray jsonArray = new JSONArray(data);
                for (int i = 0;i<jsonArray.length();i++){
                    jsonObject = jsonArray.getJSONObject(i);
                    Map<String,Object> map = new HashMap();
                    String name = jsonObject.getString("username");
                    String title = jsonObject.getString("title");
                    String text = jsonObject.getString("text");
                    String agree = String.valueOf(jsonObject.getInt("agree"));
                    String disagree = String.valueOf(jsonObject.getInt("disagree"));
                    String time = jsonObject.getString("time");
                    String comment_num = String.valueOf(jsonObject.getInt("comment_num"));
                    String comment = String.valueOf(jsonObject.getInt("comment"));

                    map.put("name",name);
                    map.put("title",title);
                    map.put("text",text);
                    map.put("agree",agree);
                    map.put("disagree",disagree);
                    map.put("time",time);
                    map.put("comment_num",comment_num);
                    map.put("comment",comment);

                    list.add(map);
                }
                //System.out.println(list.toString());
                Message message = new Message();
                message.what = 1;

                handler.sendMessage(message);


            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    public Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case 1:
                    index = 0;
                    length = list.size();
                    //System.out.println("list_size =  "+length);
                    Collections.reverse(list);
                    //复制一部分
                    for (int i = 0;i<maxNum&&i<length;i++,index++)
                    {
                        if (list!=null&&list.size()>0)
                            data.add(list.get(i));
                        // System.out.println("index1="+i);
                    }
                    adapter = new DeleteAdapter(FollowShareActivity.this,data);
                    listView.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                    listView.setOnLoadMoreListener(new LoadMoreListView.OnLoadMoreListener() {
                        @Override
                        public void onloadMore() {
                            loadMore();
                        }
                    });
                    break;
            }
        }
    };

    private void loadMore() {
        new Thread(){
            @Override
            public void run() {
                super.run();
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                //data.clear();
                int i=0;
                for (;i<maxNum&&index+i<length;i++)
                {
                    if (list!=null&&list.size()>0)
                        data.add(list.get(i+index));
                    //System.out.println("index2="+i);
                }
                index += i;

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        adapter.notifyDataSetChanged();
                        listView.setLoadCompleted();
                    }
                });
            }
        }.start();
    }
}
