package com.example.a12579.design.my.follow;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.a12579.design.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by 12579 on 2018/5/31.
 */

public class FollowAdapter extends BaseAdapter{

    private Context context;
    private ArrayList<Map<String,Object>> list;
    private ArrayList<Boolean>list_is_followed = new ArrayList<Boolean>(){};
    private RelativeLayout relativeLayout;
    private String fname;

    public FollowAdapter(Context context,ArrayList list){
        this.context = context;
        this.list = list;
        for (int i =0;i<list.size();i++)
            list_is_followed.add(true);
        SharedPreferences sharedPreferences = context.getSharedPreferences("userdata", Context.MODE_PRIVATE);
        fname = sharedPreferences.getString("name","");
    }

    @Override
    public int getCount() {
        return (list==null||list.size()==0)?0:list.size();
    }

    @Override
    public Object getItem(int i) {
        if (list!=null&&list.size()>0)
            return list.get(i);
        else
            return null;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflater = LayoutInflater.from(context);
        relativeLayout = (RelativeLayout) inflater.inflate(R.layout.cell_follow,null);

        TextView tv_name = relativeLayout.findViewById(R.id.follow_tv_name);
        TextView tv_sign = relativeLayout.findViewById(R.id.follow_tv_sign);

        ImageView iv_user = relativeLayout.findViewById(R.id.follow_img_user);
        final ImageView iv_follow = relativeLayout.findViewById(R.id.follow_iv_do_follow);

        Map<String,Object> map = list.get(i);
        tv_name.setText(map.get("name").toString());
        tv_sign.setText(map.get("sign").toString());
        if (map.get("gender").equals("女")){
            iv_user.setImageResource(R.drawable.userfemale);
        }

        iv_follow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (list_is_followed.get(i)==true)
                {
                    deleteFollow(fname,list.get(i).get("name").toString());
                    list_is_followed.set(i,false);
                    iv_follow.setImageResource(R.drawable.guanzhu);
                }else{
                    addFollow(fname,list.get(i).get("name").toString());
                    list_is_followed.set(i,true);
                    iv_follow.setImageResource(R.drawable.yiguanzhu);
                }
            }
        });
        return relativeLayout;
    }
    private void deleteFollow(final String fname, final String fedname){
        new Thread(new Runnable() {
            @Override
            public void run() {
                OkHttpClient client = new OkHttpClient();
                RequestBody requestBody = new FormBody.Builder()
                        .add("fname",fname)
                        .add("fedname",fedname)
                        .build();
                Request request = new Request.Builder()
                        .url("http://47.94.157.71/design/design/deletefollow")
                        .post(requestBody)
                        .build();
                Response response = null;
                try {
                    response = client.newCall(request).execute();
                    String responseData = response.body().string();
                    JSONObject jsonObject = new JSONObject(responseData);
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
    private void addFollow(final String fname, final String fedname){
        new Thread(new Runnable() {
            @Override
            public void run() {
                OkHttpClient client = new OkHttpClient();
                RequestBody requestBody = new FormBody.Builder()
                        .add("fname",fname)
                        .add("fedname",fedname)
                        .build();
                Request request = new Request.Builder()
                        .url("http://47.94.157.71/design/design/addfollow")
                        .post(requestBody)
                        .build();
                Response response = null;
                try {
                    response = client.newCall(request).execute();
                    String responseData = response.body().string();
                    JSONObject jsonObject = new JSONObject(responseData);
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
}
