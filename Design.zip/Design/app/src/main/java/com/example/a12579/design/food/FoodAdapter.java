package com.example.a12579.design.food;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.example.a12579.design.R;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by 12579 on 2018/6/1.
 */

class FoodAdapter extends BaseAdapter implements Filterable{

    private Context context;
    private ArrayList<Map<String,Object>> list;
    private RelativeLayout relativeLayout;
    //过滤相关
    private final Object mLock = new Object();
    //对象数组的备份，当调用ArrayFilter的时候初始化和使用。此时，对象数组只包含已经过滤的数据。
    private ArrayList<Map<String,Object>> mOriginalValue = new ArrayList<>();
    private ArrayFilter mFilter;


    public FoodAdapter(Context context, ArrayList list){
        this.context = context;
        this.list = list;
    }
    @Override
    public int getCount() {
        return (list==null||list.size()==0)?0:list.size();
    }

    @Override
    public Object getItem(int i) {
        if (list!=null&&list.size()>0)
            return list.get(i);
        else
            return null;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflater = LayoutInflater.from(context);
        relativeLayout = (RelativeLayout) inflater.inflate(R.layout.cell_food,null);

        TextView tv_name = relativeLayout.findViewById(R.id.food_tv_name);
        ImageView imageView = relativeLayout.findViewById(R.id.food_img);
        Map<String,Object> map = new HashMap<>();
        map = list.get(i);
        tv_name.setText(map.get("name").toString());
        String url = (String) map.get("url");
        Glide.with(context)
                .load(url)
                .placeholder(R.drawable.food)
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .into(imageView);
        return relativeLayout;
    }

    @Override
    public Filter getFilter() {
        if (mFilter == null) {
            mFilter = new ArrayFilter();
        }
        return mFilter;
    }

    private class ArrayFilter extends Filter{
        @Override
        protected FilterResults performFiltering(CharSequence prefix) {
            System.out.println("list"+list.size());
            System.out.println("morigin"+mOriginalValue.size());
            System.out.println("prefix"+prefix);
            FilterResults results = new FilterResults();
            if (mOriginalValue == null||mOriginalValue.size()==0){
                synchronized (mLock){
                    mOriginalValue = new ArrayList<>(list);
                }
            }
            if (prefix == null || prefix.length() == 0 ||prefix.equals("")){
                ArrayList<Map<String,Object>>data = new ArrayList<>(mOriginalValue);
                synchronized (mLock){
                    //同步复制一个原始备份数据
                    list =  new ArrayList<>(mOriginalValue);
                }
                System.out.println("首字母为空"+mOriginalValue.size());
                results.values = data;
                results.count = data.size();
            }else{
            String prefixString = prefix.toString().toLowerCase();

                ArrayList<Map<String,Object>>values;
                synchronized (mLock){
                    values = new ArrayList<>(mOriginalValue);
                }
                final int count = values.size();
                final ArrayList<Map<String,Object>> newValues = new ArrayList<>();

                for (int i = 0;i<count;i++){
                    final Map<String,Object>value = values.get(i);
                    final String valueText = value.get("name").toString().toLowerCase();
                    if (valueText.startsWith(prefixString)||valueText.indexOf(prefixString.toString())!=-1){
                        newValues.add(value);
                    }else {
                        final String[] words = valueText.split(" ");
                        final int wordCount = words.length;
                        for (int k = 0; k < wordCount; k++) {
                            if (words[k].startsWith(prefixString)) {
                                newValues.add(value);
                                break;
                            }
                        }
                    }
                }
                results.values = newValues;
                results.count = newValues.size();
            }

            return results;
        }

        @Override
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
            list = (ArrayList<Map<String, Object>>) filterResults.values;
            if (filterResults.count > 0) {
                notifyDataSetChanged();//这个相当于从mDatas中删除了一些数据，只是数据的变化，故使用notifyDataSetChanged()
            } else {
                notifyDataSetInvalidated();//当results.count<=0时，此时数据源就是重新new出来的，说明原始的数据源已经失效了
            }
        }
    }


}
