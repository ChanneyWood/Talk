package com.example.a12579.design.food;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.example.a12579.design.R;

import java.util.HashMap;

/**
 * Created by 12579 on 2018/6/2.
 */

public class SelectFood extends AppCompatActivity{
    private TextView tv_name,tv_msg;
    private ImageView imageView;
    private String name,msg,url;

    HashMap<String,Object>map;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        map = (HashMap<String, Object>) intent.getSerializableExtra("data");
        name = (String) map.get("name");
        msg = (String) map.get("msg");
        url = (String) map.get("url");

        setContentView(R.layout.select_food_layout);
        tv_name = findViewById(R.id.food_select_tv_name);
        tv_msg = findViewById(R.id.food_select_tv_msg);
        imageView = findViewById(R.id.food_select_img);
        Glide.with(this)
                .load(url)
                .placeholder(R.drawable.food)
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .into(imageView);
        tv_name.setText(name);
        tv_msg.setText(msg);

    }
}
